-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- INS00002- GIS_TB01S005_CONTINENTE
--
-- N�o efetue a elimina��o de nenhum registro desta tabela.
-- Realizar a inser��o que se encontra abaixo nesta tabela.
--     (8, 'Fantasia', 'FAN', NULL, NULL);
-- Ap�s a inser��o, exibir os dados da tabela.
--
-- Aten��o: Ocorrer� um erro na inser��o. Explique a raz�o desse erro.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Inser��o dos dados
-- ----------------------------------------------------------------------------------------
--
Insert into dbo.GIS_TB01S005_CONTINENTE values
 (8, 'Fantasia', 'FAN', NULL, NULL);
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select *
  From dbo.GIS_TB01S005_CONTINENTE;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- Observa��o:
-- Ocorreu um erro no comando INSERT  porque faltou inserir um valor para a �ltima coluna.
-- A tabela possui grau 6, ou seja, apresenta 6 (seis) colunas.
-- Mas o comando INSERT  est� gravando apenas 5 (cinco) valores.
--
-- A mensagem de erro alerta para o fato de que o nome da coluna  ou o n�mero de valores  a
-- serem inseridos n�o coincide com a defini��o da tabela.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 INS00002
-- ----------------------------------------------------------------------------------------
--
--
