-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY007- GIS_TB01S005_CONTINENTE
--
-- Selecionar todos os continentes,  explicitando  as colunas no comando  e colocando label
-- nestas colunas, para que o usu�rio possa melhor entender o relat�rio gerado.
-- Aten��o: Retirar o ap�strofe (') do r�tulo (label) da coluna OBS.
--          Verificar o que ocorre.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select codigo            'C�digo do Continente',
       nome              'Nome do Continente',
       sigla             'Sigla do Continente',
       ext_km2           'Extens�o territorial (Km quadrados)',
       obs               Coment�rio,
       data_atual        'Data da atualiza��o' 
  From dbo.GIS_TB01S005_CONTINENTE;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A rela��o das colunas  no comando SELECT  n�o precisa obedecer  a ordem de sequ�ncia das
-- colunas na tabela.  A sequ�ncia das colunas pode ser feita na ordem  que for mais conve-
-- niente.
--
-- Reparar que a �ltima coluna relacionada  no comando SELECT, antes da cl�usula FROM,  n�o
-- � acompanhada de v�rgula, exatamente por ser a �ltima coluna do comando.
--
-- O uso do R�tulo da coluna (ou Label da coluna ou cabe�alho da coluna) permite imprimir o
-- resultado do comando SELECT com o nome mais adequado das colunas para o entendimento dos
-- usu�rios, ao inv�s de imprimir o nome da coluna no cabe�alho.
--
-- A aus�ncia do ap�strofe em um label onde existe  uma �nica palavra  n�o acarreta nenhuma
-- consequ�ncia.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY007
-- ----------------------------------------------------------------------------------------
--
--
