-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY009- GIS_TB01S005_CONTINENTE
--
-- Selecionar todos os continentes,  explicitando  as colunas no comando  e colocando label
-- nestas colunas, para que o usu�rio possa melhor entender o relat�rio gerado.
-- Aten��o: Exibir as 3 primeiras linhas do grid de exibi��o.
--          N�o usar cl�usula Where.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select TOP 3
       codigo         'C�digo do Continente',
       nome           'Nome do Continente',
       sigla          'Sigla do Continente',
       ext_km2        'Extens�o territorial (Km quadrados)',
       obs            'Coment�rio',
       data_atual     'Data da atualiza��o'
  From dbo.GIS_TB01S005_CONTINENTE;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A op��o TOP permite que se determine o  n�mero de tuplas do grid de sa�da  que se deseja
-- exibir.
--
-- A op��o TOP 3 indica que se deseja exibir apenas as 3 primeiras linhas do grid de sa�da.
--
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY009
-- ----------------------------------------------------------------------------------------
--
--
