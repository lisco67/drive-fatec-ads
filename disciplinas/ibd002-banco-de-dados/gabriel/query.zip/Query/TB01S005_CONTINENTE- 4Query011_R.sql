-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY011- GIS_TB01S005_CONTINENTE
--
-- Selecionar todos os continentes,  explicitando  as colunas no comando  e colocando label
-- nestas colunas, para que o usu�rio possa melhor entender o relat�rio gerado.
-- Aten��o: Ordenar a sa�da pela coluna NOME, em ordem decrescente.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select codigo           'C�digo do Continente',
       nome             'Nome do Continente',
       sigla            'Sigla do Continente',
       ext_km2          'Extens�o territorial (Km quadrados)',
       obs              'Coment�rio',
       data_atual       'Data da atualiza��o'
  From dbo.GIS_TB01S005_CONTINENTE
  Order by nome DESC;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- A cl�usula ORDER BY � opcional. O seu uso permite determinar a ordem de exibi��o das li-
-- nhas da tabela.
--
-- A cl�usula ORDER BY deve ser colocada ap�s a cl�usula WHERE, caso esta exista.
--
-- Quando a cl�usula ORDER BY n�o � utilizada, a ordem de exibi��o das linhas da tabela  a-
-- contece de acordo com a Chave Prim�ria (Primary Key), desde que ela tenha mantido o  de-
-- fault de ser uma chave clustered.
--
-- A chave clustered � a chave que ordena fisicamente as linhas da tabela.
--
-- Na cl�usula ORDER BY, a op��o ASC (ordem crescente de exibi��o pela coluna) � o default.
-- Isto significa que n�o � necess�rio escrever esta op��o (ASC)  para que a exibi��o ocor-
-- ra em ordem crescente.
--
-- Na cl�usula ORDER BY,  usa-se a  op��o DESC  (ordem decrescente de exibi��o pela coluna)
-- para a exibi��o das linhas da tabela em ordem decrescente.
--
-- As colunas que aparecem na cl�usula ORDER BY devem aparecer tamb�m  na sele��o da tupla,
-- ou seja, ao lado do comando SELECT.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY011
-- ----------------------------------------------------------------------------------------
--
--
