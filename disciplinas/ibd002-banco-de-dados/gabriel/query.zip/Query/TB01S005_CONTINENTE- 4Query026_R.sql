-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY026- GIS_TB01S005_CONTINENTE
--
-- Mostrar o valor bin�rio da soma de verifica��o calculado para cada linha de tabela.
-- Aten��o: Colocar label (r�tulo) na coluna resultante.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select binary_checksum(*) 'Binary Checksum'
  From dbo.GIS_TB01S005_CONTINENTE;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- As Fun��es de Agrega��o s�o declaradas no comando SELECT  tal qual se faz com a declara-
-- ��o de uma coluna.
--
-- Uma fun��o de agrega��o, ao ser exibida, ter� como nome de coluna  "COLUMN NO NAME",  ou
-- seja, "Coluna Sem Nome", porque sua origem n�o � da pr�pria tabela.
--
-- Para evitar este nome de coluna, utiliza-se de um label ou r�tulo de coluna.
--
-- Esta fun��o retorna o valor bin�rio da soma de verifica��o calculado em uma linha de ta-
-- bela ou em uma lista de express�es.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY026
-- ----------------------------------------------------------------------------------------
--
--
BINARY_CHECKSUM(*), calculado em qualquer linha de uma tabela, retorna o mesmo valor enquanto a linha n�o for modificada subsequentemente. BINARY_CHECKSUM atende �s propriedades de uma fun��o de hash: BINARY_CHECKSUM, aplicado a duas listas de express�es quaisquer, retorna o mesmo valor se os elementos correspondentes das duas listas t�m o mesmo tipo e s�o iguais, quando comparados usando o operador de igualdade (=). Para essa defini��o, dizemos que valores nulos, de um tipo especificado, s�o comparados como valores iguais. Se, pelo menos, um dos valores na lista de express�es for alterado, a soma de verifica��o da express�o tamb�m poder� ser alterada. No entanto, isso n�o � garantido. Portanto, para detectar se os valores foram alterados, recomendamos o uso de BINARY_CHECKSUM somente se o aplicativo puder tolerar uma altera��o ausente ocasional. Caso contr�rio, considere o uso de HashBytes. Com um algoritmo de hash MD5 especificado, a probabilidade de que HashBytes retornar� o mesmo resultado para duas entradas diferentes � muito menor em compara��o com BINARY_CHECKSUM.
BINARY_CHECKSUM pode operar sobre uma lista de express�es e retorna o mesmo valor para uma lista especificada. BINARY_CHECKSUM aplicado sobre duas listas de express�es retorna o mesmo valor se os elementos correspondentes das duas listas tiverem o mesmo tipo e representa��o de byte. Nessa defini��o, os valores nulos de um tipo especificado s�o considerados como possuidores da mesma representa��o de byte.
BINARY_CHECKSUM e CHECKSUM s�o fun��es semelhantes: Elas podem ser usadas para calcular um valor de soma em uma lista de express�es e a ordem das express�es afeta o valor resultante. A ordem de colunas usada em BINARY_CHECKSUM(*) � a ordem de colunas especificada na tabela ou defini��o de exibi��o. Isso inclui as colunas computadas.
BINARY_CHECKSUM e CHECKSUM retornam valores diferentes para os tipos de dados de cadeia de caracteres, em que a localidade pode fazer com que as cadeias de caracteres com uma representa��o diferente sejam comparadas como iguais. Os tipos de dados de cadeia de caracteres s�o

char
nchar
nvarchar
varchar
ou em

sql_variant (se o tipo base de sql_variant for um tipo de dados string).
Por exemplo, as cadeias de caracteres "McCavity" e "Mccavity" t�m diferentes valores BINARY_CHECKSUM. Por outro lado, para um servidor que n�o diferencia mai�sculas de min�sculas, CHECKSUM retorna os mesmos valores de soma de verifica��o para essas cadeias de caracteres. Voc� deve evitar a compara��o de valores de soma CHECKSUM com valores de BINARY_CHECKSUM.
BINARY_CHECKSUM � compat�vel com at� 8.000 caracteres do tipo varbinary(max) e at� 255 caracteres do tipo nvarchar(max).


BINARY_CHECKSUM

Retorna o valor da soma de verifica��o bin�ria calculado sobre uma linha de uma tabela ou sobre uma lista de express�es. BINARY_CHECKSUM pode ser usado para detectar altera��es em uma linha de uma tabela.

Ele sugere que a soma de verifica��o bin�ria deve ser usada para detectar altera��es de linha, mas n�o por qu�.

