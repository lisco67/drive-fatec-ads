-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY029- GIS_TB01S005_CONTINENTE
--
-- Mostrar o valor de agrupamento.
-- Aten��o: Colocar label (r�tulo) na coluna resultante.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select ext_km2, grouping(ext_km2) 'Grouping'
  From dbo.GIS_TB01S005_CONTINENTE
  Group by ext_km2;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- As Fun��es de Agrega��o s�o declaradas no comando SELECT  tal qual se faz com a declara-
-- ��o de uma coluna.
--
-- Uma fun��o de agrega��o, ao ser exibida, ter� como nome de coluna  "COLUMN NO NAME",  ou
-- seja, "Coluna Sem Nome", porque sua origem n�o � da pr�pria tabela.
--
-- Para evitar este nome de coluna, utiliza-se de um label ou r�tulo de coluna.
--
-- Esta fun��o GROUPING(col)  indica se uma  express�o de coluna  especificada em uma lista
-- GROUP BY � agregada ou n�o.
-- GROUPING retorna 1 para agregada ou 0 para n�o agregada no conjunto de resultados.
-- GROUPING pode ser usado  apenas na lista  SELECT <select>,  nas cl�usulas HAVING e ORDER
-- BY, quando GROUP BY � especificado.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY029
-- ----------------------------------------------------------------------------------------
--
--

