-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY033- GIS_TB01S005_CONTINENTE
--
-- Qual � o total de continentes?
-- Qual � a �rea total de todos os continentes?
-- Qual � a �rea m�dia dos continentes?
-- Qual � a �rea do menor dos continentes?
-- Qual � a �rea do maior dos continentes?
-- Aten��o: imprimir os valores juntos.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select count(*)     'Total de continentes',
       sum(ext_km2) '�rea dos continentes',
       avg(ext_km2) '�rea m�dia dos continentes',
       min(ext_km2) 'Menor �rea dos continentes',
       max(ext_km2) 'Maior �rea dos continentes'
  From dbo.GIS_TB01S005_CONTINENTE;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- As cl�usulas (FROM, WHERE, ORDER BY e outras) aparecem uma �nica vez no comando SELECT.
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- A cl�usula WHERE � um filtro de sele��o de tuplas, permitindo a exibi��o somente das tu-
-- plas que atenderem � restri��o constante na cl�usula.
--
-- O uso do R�tulo da coluna (ou Label da coluna ou cabe�alho da coluna) permite imprimir o
-- resultado do comando SELECT com o nome mais adequado das colunas para o entendimento dos
-- usu�rios, ao inv�s de imprimir o nome da coluna no cabe�alho.
--
-- As fun��es de agrega��o s�o declaradas no comando SELECT  tal qual se faz com a declara-
-- ��o de uma coluna.
--
-- Em um mesmo comando SELECT, � poss�vel exibir v�rias fun��es de agrega��o.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY033
-- ----------------------------------------------------------------------------------------
--
--
