-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY035- GIS_TB01S005_CONTINENTE
--
-- Qual � o nome do continente que possui a maior extens�o?
-- Aten��o: Usar subselect.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select codigo        'C�digo do continente',
       sigla         'Sigla',
       nome          'Nome',
       ext_km2       'Extens�o (Km quadrados)',
       obs           'Coment�rio'
  From dbo.GIS_TB01S005_CONTINENTE
  Where ext_km2 =
     (Select max(ext_km2)                  -- Este � o Subselect
        From dbo.GIS_TB01S005_CONTINENTE);
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- As cl�usulas (FROM, WHERE, ORDER BY e outras) aparecem uma �nica vez no comando SELECT.
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- A cl�usula WHERE � um filtro de sele��o de tuplas, permitindo a exibi��o somente das tu-
-- plas que atenderem � restri��o constante na cl�usula.
--
-- Um SUBSELECT nada mais do � do que um comando SELECT dentro de outro comando SELECT.
--
-- O SUBSELECT � facilmente identific�vel pois o comando SELECT inicia com um "(", ou seja,
-- com um abre par�nteses.
--
-- A SQL inicia a execu��o dos SELECTs pelo SELECT mais interno e termina com o SELECT mais
-- externo (ou seja, executa do fim para o come�o).
--
-- Pode haver at� 15 (quinze) n�veis de SUBSELECT.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY035
-- ----------------------------------------------------------------------------------------
--
--
