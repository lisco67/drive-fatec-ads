-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY047- GIS_TB01S005_CONTINENTE
--
-- Quais s�o  os continentes cujo nome  n�o possui as letras  "N" ou "C"  em alguma posi��o
-- (nesta sequ�ncia ou na sequ�ncia inversa)?
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select codigo        'C�digo do continente',
       sigla         'Sigla',
       nome          'Nome',
       ext_km2       'Extens�o (Km quadrados)',
       obs           'Coment�rio'
  From dbo.GIS_TB01S005_CONTINENTE
  Where nome not like '%n%c%'
    and nome not like '%c%n%'
    and nome not like 'N%c%   -- Estes 2 predicados foram colocados porque o Like faz
    and nome not like 'C%n%   -- diferencia��o entre mai�sculas e min�sculas.
;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- As cl�usulas (FROM, WHERE, ORDER BY e outras) aparecem uma �nica vez no comando SELECT.
--
-- A cl�usula FROM � a �nica cl�usula obrigat�ria no comando SELECT.
--
-- A cl�usula WHERE � um filtro de sele��o de tuplas, permitindo a exibi��o somente das tu-
-- plas que atenderem � restri��o constante na cl�usula.
--
-- O predicado LIKE permite varrer strings em busca de combina��es informadas.
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY047
-- ----------------------------------------------------------------------------------------
--
--
