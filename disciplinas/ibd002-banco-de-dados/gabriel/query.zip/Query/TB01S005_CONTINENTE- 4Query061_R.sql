-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY061- GIS_TB01S005_CONTINENTE
--
-- Quais s�o os continentes cuja coluna observa��o (obs) encontra-se com valor nulo?
-- Aten��o: Exibir os dados, colocando na primeira, na segunda e na terceira colunas a Data
-- e a Hora correntes (ou seja, a data e hora locais ou data e hora de Bras�lia).
-- Para a primeira coluna, somar o valor 01 no dia. 
-- Para a segunda coluna, somar o valor 02 no m�s. 
-- Para a terceira coluna, somar o valor 03 no ano. 
-- Aten��o: Exibir os dados, colocando na quarta, na quinta e na sexta colunas a  Data  e a
-- Hora de Greenwich (ou seja, a data e hora internacional ou data e hora de Londres).
-- Para a quarta coluna, somar o valor 01 no dia. 
-- Para a quinta coluna, somar o valor 02 no m�s. 
-- Para a sexta coluna, somar o valor 03 no ano. 
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select Dateadd (Day, 01, Getdate())    'Hora local, dia + 1',
       ' - '         ' ',
       Dateadd (Month, 02, Getdate())  'Hora local, m�s + 2',
       ' - '         ' ',
       Dateadd (Year, 03, Getdate())   'Hora local, ano + 3',
       ' - '         ' ',
       Dateadd (Day, 01, Getutcdate())    'Hora intern., dia + 1',
       ' - '         ' ',
       Dateadd (Month, 02, Getutcdate())  'Hora intern., m�s + 2',
       ' - '         ' ',
       Dateadd (Year, 03, Getutcdate())   'Hora intern., ano + 3',
       ' - '         ' ',
       codigo        'C�digo do continente',
       sigla         'Sigla',
       nome          'Nome',
       ext_km2       'Extens�o (Km quadrados)',
       obs           'Coment�rio'
  From dbo.GIS_TB01S005_CONTINENTE
  Where obs IS NULL;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A fun��o DateAdd adiciona um valor num�rico  a uma parte do valor da data  (como no dia,
-- ou no m�s ou no ano).
--
-- O predicado IS NULL permite verificar se o conte�do de uma coluna � ou n�o nulo (NULL).
--
-- O valor NULL corresponde ao conjunto vazio, significando o valor dado para a aus�ncia de
-- valor. Ele n�o � 0 (zero) e nem � branco.
--
-- A fun��o GETDATE() recolhe a data e hora correntes (ou seja, a data e hora locais ou da-
-- ta e hora de Bras�lia).
--
-- A fun��o GETUTCDATE() recolhe a data e hora conforme o Meridiano de Greenwich  (ou seja,
-- a data e hora de Londres, ou ainda UTC, que � a sigla para Universal Time Coordinate).
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY061
-- ----------------------------------------------------------------------------------------
--
--
