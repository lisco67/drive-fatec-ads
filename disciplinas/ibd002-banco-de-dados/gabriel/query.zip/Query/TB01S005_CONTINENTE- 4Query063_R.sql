-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY063- GIS_TB01S005_CONTINENTE
--
-- Quais s�o os continentes cuja coluna observa��o (obs) encontra-se com valor nulo?
-- Aten��o: Exibir os dados, colocando na primeira coluna a data e a hora correntes (ou se-
--          ja, a data e hora locais ou de Bras�lia).
--          Colocar uma coluna de separa��o entre a data corrente e os demais dados, de mo-
--          do que o nome desta coluna fique em branco.
--          Em seguida, efetuar a diferen�a desta data para a data 28 de novembro de 2017.
--          Mostrar o resultado da diferen�a em anos.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select Getdate()    'Hora de Bras�lia',
       ' - '        ' ',
       DateDiff (Year, Getdate(), '2017-11-28') AS 'Diferen�a de data',
       ' - '        ' ',
       codigo       'C�digo do continente',
       sigla        'Sigla',
       nome         'Nome',
       ext_km2      'Extens�o (Km quadrados)',
       obs          'Coment�rio'
  From dbo.GIS_TB01S005_CONTINENTE
  Where obs IS NULL;
--
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A fun��o DateDiff retorna um valor que corresponde � contagem dos limites  das datas es-
-- pecificadas entre a data inicial e a data final.
--
-- O valor inicial � subtra�do do valor final da data.
--
-- O resultado � dado em anos, porque foi especificado YEAR como primeiro par�metro da fun-
-- ��o.
--
-- O predicado IS NULL permite verificar se o conte�do de uma coluna � ou n�o nulo (NULL).
--
-- O valor NULL corresponde ao conjunto vazio, significando o valor dado para a aus�ncia de
-- valor. Ele n�o � 0 (zero) e nem � branco.
--
-- A fun��o GETDATE() recolhe a data e hora correntes (ou seja, a data e hora locais ou da-
-- ta e hora de Bras�lia).
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY063
-- ----------------------------------------------------------------------------------------
--
--
