-- ----------------------------------------------------------------------------------------
-- Gabriel Issa Shammas (GIS) - 01 de janeiro de 2000 a 31 de dezembro de 2020
-- ----------------------------------------------------------------------------------------
-- QUERY067- GIS_TB01S005_CONTINENTE
--
-- A partir da primeira coluna, exibir a parte correspondente  ao ano da data corrente,  em
-- seguida, exibir a parte correspondente ao m�s e � parte correspondente ao dia.
-- Em seguida, exibir o dia corrido da data corrente, a semana da data, o dia da semana e o
-- quartil da data corrente.
-- Exibir tamb�m a hora da data corrente, o minuto, o segundo, o milisegundo, o microsegun-
-- do e o nanosegundo da data corrente.
--
-- ----------------------------------------------------------------------------------------
-- Aten��o. Indica��o do BD a ser usado. Se for o caso, mude o nome do Banco.
-- ----------------------------------------------------------------------------------------
--
USE BDGIS;
--
-- ----------------------------------------------------------------------------------------
-- Sele��o de todos os dados para visualiza��o do conte�do da tabela.
-- ----------------------------------------------------------------------------------------
--
Select datename (year, getdate())        'Ano da data',
       datename (month, getdate())       'M�s da data',
       datename (day, getdate())         'Dia da data',
       datename (dayofyear, getdate())   'Dia corrido da data',
       datename (week, getdate())        'Semana da data',
       datename (weekday, getdate())     'Dia da semana da data',
       datename (quarter, getdate())     'Quartil da data',
       ' '                               ' - ',
       datename (hour, getdate())        'Hora da data',
       datename (minute, getdate())      'Minuto da data',
       datename (second, getdate())      'Segundo da data',
       datename (millisecond, getdate()) 'Milisegundo da data',
       datename (microsecond, getdate()) 'Microsegundo da data',
       datename (nanosecond, getdate())  'Nanosegundo da data',
       ' '                               ' - ';
--  
-- ----------------------------------------------------------------------------------------
-- Coment�rios.
-- ----------------------------------------------------------------------------------------
--
-- A fun��o Datename retorna um valor que corresponde � parte especificada  do argumento de
-- data que foi especificada.
--
-- Reparar que n�o � necess�rio selecionar nenhum dado de nenhuma tabela para exibir a data
-- e hora correntes e nem para fazer os c�lculos.
--
-- A fun��o GETDATE() recolhe a data e hora correntes (ou seja, a data e hora locais ou da-
-- ta e hora de Bras�lia).
--
-- ----------------------------------------------------------------------------------------
-- Fim TB01S005 QUERY067
-- ----------------------------------------------------------------------------------------
--
--
